package com.example.welcome.msit_attendance_track;

/**
 * Created by welcome on 4/14/2018.
 */

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class thirdactivity extends AppCompatActivity {
    ListView list;
    Activity act;
    String[] time1 = {}, penalty1 = {},abpresent1={},session1={},latitude1={},longitude1={};
    List<String> time = new ArrayList<>(),penalty = new ArrayList<>(),abpresent = new ArrayList<>(),
            session=new ArrayList<>(),latitude=new ArrayList<>(),longitude=new ArrayList<>();
    DBAdapter db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewattendance);
        db = new DBAdapter(this);
        act = this;
        GetContacts();
    }
    public void GetContacts() {
        //--get all contacts---
        db.open();
        Cursor c = db.getAllContacts();
        if (c.moveToFirst())
        {
            do {
                DisplayContact(c);
            } while (c.moveToNext());
        }
        db.close();
    }
    public void DisplayContact(Cursor c)
    {
        time.add(c.getString(0));
        penalty.add(c.getString(1));
        abpresent.add(c.getString(2));
        session.add(c.getString(3));
        latitude.add(c.getString(4));
        longitude.add(c.getString(5));
        time1 = time.toArray(time1);
        penalty1 =penalty.toArray(penalty1);
        abpresent1=abpresent.toArray(abpresent1);
        session1=session.toArray(session1);
        latitude1=latitude.toArray(latitude1);
        longitude1=longitude.toArray(longitude1);
        CustomListAdaptor1 adapter = new CustomListAdaptor1(act,session1,time1, penalty1,abpresent1,latitude1,longitude1);
        list = (ListView)findViewById(R.id.listview2);
        list.setAdapter(adapter);
    }

}


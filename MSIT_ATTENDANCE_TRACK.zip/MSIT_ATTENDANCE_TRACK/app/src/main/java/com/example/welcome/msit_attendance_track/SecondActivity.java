package com.example.welcome.msit_attendance_track;

/**
 * Created by welcome on 4/14/2018.
 */

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SecondActivity extends AppCompatActivity {
    String[] keys = {}, values = {};
    List<String> keysList = new ArrayList<>(),valuesList = new ArrayList<>();

    String Url = "http://msitis-iiith.appspot.com/api/profile/ag5ifm1zaXRpcy1paWl0aHIUCxIHU3R1ZGVudBiAgICA-MLECAw";
    JsonObjectRequest jsonObjectRequest;

    ListView list;
    Activity act;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        act = this;

        RequestQueue queue = Volley.newRequestQueue(this);
        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, Url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONObject profile = response.getJSONArray("data").getJSONObject(0);
                    Iterator<String> iter = profile.keys();
                    while (iter.hasNext()) {
                        String currentKey = iter.next(),
                                currentVal = profile.getString(currentKey);
                        if(!currentVal.isEmpty()) {
                            keysList.add(currentKey);
                            valuesList.add(currentVal);
                        }
                    }

                    keys = keysList.toArray(keys);
                    values = valuesList.toArray(values);

                    CustomListAdaptor adapter = new CustomListAdaptor(act, keys, values);

                    try {
                        ImageView image = (ImageView) findViewById(R.id.imageView);
                        byte[] latinBytes = profile.getString("image").getBytes("ISO-8859-1");
                        String b64 = Base64.encodeToString(latinBytes, Base64.DEFAULT);
                        byte[] imgBytes = Base64.decode(b64, Base64.DEFAULT);
                        Bitmap decodedImage = BitmapFactory.decodeByteArray(imgBytes, 0, imgBytes.length);
                        image.setImageBitmap(decodedImage);
                    } catch(Exception ex) {
                        ex.printStackTrace();
                    }

                    list = (ListView)findViewById(R.id.listview1);

                    list.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        queue.add(jsonObjectRequest);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.profile, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//
//        if (id == R.id.logout_menu) {
//            Intent intent = new Intent(this,MainActivity.class);
//            startActivity(intent);
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
}

package com.example.welcome.msit_attendance_track;

/**
 * Created by welcome on 4/14/2018.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBAdapter {
    static final String KEY_ROWID = "_id";
    static final String KEY_session = "session";
    static final String KEY_time = "time";
    static final String KEY_penalty = "penalty";
    static final String KEY_abpresent = "abpresent";
    static final String KEY_lat="latitude";
    static final String KEY_long="longitude";
    static final String TAG = "DBAdapter";

    static final String DATABASE_NAME = "MyDB10";
    static final String DATABASE_TABLE = "attendance";
    static final int DATABASE_VERSION = 1;

    static final String DATABASE_CREATE =
            "create table attendance (_id integer primary key autoincrement , "
                    + "session text not null,time text not null,penalty text not null, abpresent text not null,latitude text not null,longitude text not null);";

    final Context context;

    DatabaseHelper DBHelper;
    SQLiteDatabase db;

    public DBAdapter(Context ctx) {
        this.context = ctx;
        DBHelper = new DatabaseHelper(context);
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {
        DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            try {
                db.execSQL(DATABASE_CREATE);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS attendance");
            onCreate(db);
        }

    }
    public DBAdapter open() throws SQLException
    {
        db = DBHelper.getWritableDatabase();
        return this;
    }

    //---closes the database---
    public void close()
    {
        DBHelper.close();
    }
    public long insertContact(String session,String time, String penalty,String abpresent,String latitude,String longitude)
    {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_time, time);
        initialValues.put(KEY_penalty, penalty);
        initialValues.put(KEY_abpresent, abpresent);
        initialValues.put(KEY_session,session);
        initialValues.put(KEY_lat,latitude);
        initialValues.put(KEY_long,longitude);
        return db.insert(DATABASE_TABLE, null, initialValues);
    }
    public Cursor getAllContacts()
    {
        return db.query(DATABASE_TABLE, new String[] {KEY_time, KEY_penalty,
                KEY_abpresent,KEY_session,KEY_lat,KEY_long}, null, null, null, null, null);
    }

}

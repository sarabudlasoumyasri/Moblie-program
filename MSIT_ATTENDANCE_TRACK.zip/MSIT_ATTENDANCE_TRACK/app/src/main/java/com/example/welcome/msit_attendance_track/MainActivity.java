package com.example.welcome.msit_attendance_track;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button button1;
    DBAdapter db;
    public double latitude;
    public double longitude;
    public long counter;

    ArrayList<Integer> dates = new ArrayList<>();
    TextView textView;
    public LocationManager locationManager;
    public Criteria criteria;
    public String bestProvider;
    private Handler handler;
    private Runnable runnable;
    private long timeleft = 0;
    Calendar rightNow;
    Date eightfifty;
    Date nineten;
    Date tenfifty;
    Date eleventen;
    Date onefifty;
    Date twoten;
    Date currenttime;
    ArrayList<String> sessions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 9);
        calendar.set(Calendar.MINUTE, 02);
        calendar.set(Calendar.SECOND, 30);
        calendar.set(Calendar.HOUR_OF_DAY, 11);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 30);
        calendar.set(Calendar.HOUR_OF_DAY, 14);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 30);
        Intent intent1 = new Intent(getApplicationContext(), Notification_receiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 66, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        am.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent);
        db = new DBAdapter(this);
        requestPermissions();
        Button mBtn1 = (Button) findViewById(R.id.button3);
        mBtn1.setOnClickListener(this);
        button1 = (Button) findViewById(R.id.button);
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        starttimer();
        Date date = new Date();
        try {
            db.open();
            Cursor c = db.getAllContacts();
            data();
            if ((sdf.parse(sdf.format(date)).getTime() >= sdf.parse("08:50").getTime() && sdf.parse(sdf.format(date)).getTime() <= sdf.parse("9:10").getTime()) ||
                    (sdf.parse(sdf.format(date)).getTime() >= sdf.parse("10:50").getTime() && sdf.parse(sdf.format(date)).getTime() <= sdf.parse("11:10").getTime())
                    || (sdf.parse(sdf.format(date)).getTime() >= sdf.parse("13:50").getTime() && sdf.parse(sdf.format(date)).getTime() <= sdf.parse("14:10").getTime())) {
                button1.setEnabled(true);


            } else {
                button1.setEnabled(false);
                if (sdf.parse(sdf.format(date)).getTime() > sdf.parse("18:10").getTime()) {

                    if (!dates.contains(dateFormat.parse(dateFormat.format(date)).getDate())) {

                        db.insertContact("session1", dateFormat.format(date), "0.25", "a", "null", "null");
                        data();
                    }

                    try {
                        if (dates.contains(dateFormat.parse(dateFormat.format(date)).getDate())
                                && !sessions.contains("session1")) {
                            db.insertContact("session1", dateFormat.format(date), "0.25", "a", "null", "null");

                        }
                        if (dates.contains(dateFormat.parse(dateFormat.format(date)).getDate())
                                && !sessions.contains("session2")) {
                            db.insertContact("session2", dateFormat.format(date), "0.25", "a", "null", "null");

                        }
                        if (dates.contains(dateFormat.parse(dateFormat.format(date)).getDate())
                                && !sessions.contains("session3")) {
                            db.insertContact("session3", dateFormat.format(date), "0.5", "a", "null", "null");

                        }
                    } catch (ParseException e1) {
                        e1.printStackTrace();
                    }

                } else {
                    Addattendance(null);

                }
            }
        } catch (ParseException e1) {
            e1.printStackTrace();
        }
        db.close();

    }

    public void starttimer() {
        handler = new Handler();

        runnable = new Runnable() {

            @Override
            public void run() {
                handler.postDelayed(this, 1000);
                try {
                    String thisdate = "";
                    SimpleDateFormat format1 = new SimpleDateFormat("dd-MM-yyyy");
                    Date date = new Date();
                    try {
                        thisdate = format1.format(rightNow.getTime());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }


                    rightNow = Calendar.getInstance(Locale.ROOT);
                    SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
                    currenttime = format.parse(format.format(rightNow.getTime()));
                    eightfifty = format.parse("08:50:00");
                    nineten = format.parse("9:10:00");
                    tenfifty = format.parse("10:50:00");
                    eleventen = format.parse("11:10:00");
                    onefifty = format.parse("13:20:00");
                    twoten = format.parse("14:10:00");
                    if ((currenttime.after(eightfifty) && currenttime.before(nineten)) || (currenttime.after(tenfifty) && currenttime.before(eleventen)) || (currenttime.after(onefifty) && currenttime.before(twoten))) {
                        if (currenttime.after(eightfifty) && currenttime.before(nineten)) {
                            notificationcall();
                            if (!dates.contains(format1.parse(format1.format(date)).getDate())) {

                                timeleft = nineten.getTime() - currenttime.getTime();
                            }
                            if (dates.contains(format1.parse(format1.format(date)).getDate()) && sessions.contains("session1")) {
                                timeleft = nineten.getTime() - currenttime.getTime();
                            }
                        } else if (currenttime.after(tenfifty) && currenttime.before(eleventen)) {
                            notificationcall();
                            if (!dates.contains(format1.parse(format1.format(date)).getDate())) {

                                timeleft = eleventen.getTime() - currenttime.getTime();
                            }
                            if (dates.contains(format1.parse(format1.format(date)).getDate()) && sessions.contains("session2")) {
                                timeleft = eleventen.getTime() - currenttime.getTime();
                            }

                        } else if (currenttime.after(onefifty) && currenttime.before(twoten)) {
                            notificationcall();
                            if (!dates.contains(format1.parse(format1.format(date)).getDate())) {

                                timeleft = twoten.getTime() - currenttime.getTime();
                            }
                            if (dates.contains(format1.parse(format1.format(date)).getDate()) && sessions.contains("session3")) {
                                timeleft = twoten.getTime() - currenttime.getTime();
                            }

                        }

                        long timetowork = timeleft;
                        int hr = (int) timetowork / 3600000;
                        timetowork = timetowork % 3600000;
                        int min = (int) (timetowork / 60000);
                        int sec = (int) (timetowork % 60000) / 1000;
                        String timetodisplay = "" + hr + " : " + min + " : ";
                        if (sec < 10) {
                            timetodisplay += "0";
                        }
                        timetodisplay += sec;
                        TextView time = (TextView) findViewById(R.id.textView2);
                        time.setText(timetodisplay);
                    } else {
                        TextView textv = (TextView) findViewById(R.id.textView2);
                        textv.setText("Time to mark attendance expired");
                    }
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }
        };
        handler.postDelayed(runnable, 1 * 1000);
    }
    public void notificationcall(){
        Log.e("================", "notificationcall: ");
        Calendar calendar = Calendar.getInstance();
        Intent intent1 = new Intent(getApplicationContext(), Notification_receiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 66,intent1, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
        am.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent);

    }
    public void data(){
        db.open();
        Cursor c = db.getAllContacts();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Date date = new Date();
        if (c.moveToFirst() && c!=null) {
            do {
                try {
                    if (!dates.contains(dateFormat.parse(c.getString(0)).getDate())) {
                        dates.add(dateFormat.parse(c.getString(0)).getDate());
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            } while (c.moveToNext());
        }

        try {
            if (dates.contains(dateFormat.parse(dateFormat.format(date)).getDate())) {
                sessions = new ArrayList<>();
                if (c.moveToFirst() && c!=null) {
                    do {
                        if (dateFormat.parse(c.getString(0)).getDate() == dateFormat.parse(dateFormat.format(date)).getDate()) {
                            sessions.add(c.getString(3));
                        }
                    } while (c.moveToNext());
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }


    public void onClick(View v) {
        Log.i("clicks","You Clicked B1");
        Intent i=new Intent(MainActivity.this, thirdactivity.class);
        startActivity(i);
    }
    public static boolean isLocationEnabled(Context context)
    {
        //...............
        return true;
    }
    @SuppressLint("MissingPermission")
    public void Addattendance(View view) {
        if (isLocationEnabled(MainActivity.this)) {
            locationManager = (LocationManager)  this.getSystemService(Context.LOCATION_SERVICE);
            criteria = new Criteria();
            bestProvider = String.valueOf(locationManager.getBestProvider(criteria, true)).toString();
            LocationListener myloclist = new MainActivity.MylocListener();
            //You can still do this if you like, you might get lucky:
            Location location = locationManager.getLastKnownLocation(bestProvider);
            if (location != null) {
                Log.e("TAG", "GPS is on");
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                Toast.makeText(MainActivity.this, "latitude:" + latitude + " longitude:" + longitude, Toast.LENGTH_SHORT).show();
            }
            else{
                //This is what you need:
                locationManager.requestLocationUpdates(bestProvider, 0, 0,  myloclist);
            }
        }
        data();
        db.open();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        Date date = new Date();
        String date1 = dateFormat.format(date);
        try {
            Date d2 = sdf.parse("09:10");
            long t2 = d2.getTime();
            Date d3 = sdf.parse(sdf.format(date));
            long t3 = d3.getTime();
            if (t3 >= sdf.parse("08:50").getTime() && t3 <= t2) {
                if (!dates.contains(dateFormat.parse(dateFormat.format(date)).getDate())) {
                    if (db.insertContact("session1", date1, "0", "p",Double.toString(latitude),Double.toString(longitude)) >= 0) {
                        Toast.makeText(this, "Check-in successful.", Toast.LENGTH_LONG).show();
                    }
                }
                if (dates.contains(dateFormat.parse(dateFormat.format(date)).getDate()) && !sessions.contains("session1")) {
                    if (db.insertContact("session1", date1, "0", "p",Double.toString(latitude),Double.toString(longitude)) >= 0) {
                        Toast.makeText(this, "Check-in successful.", Toast.LENGTH_LONG).show();
                    }
                }

                return;

            }

            Date d1 = sdf.parse("10:50");
            long t1 = d1.getTime();
            d2 = sdf.parse("11:10");
            t2 = d2.getTime();
            if (t3 >= t1 && t3 <= t2) {

                if (!dates.contains(dateFormat.parse(dateFormat.format(date)).getDate())) {
                    if (db.insertContact("session2", date1, "0", "p",Double.toString(latitude),Double.toString(longitude)) >= 0) {
                        Toast.makeText(this, "Check-in successful.", Toast.LENGTH_LONG).show();
                    }
                }
                if (dates.contains(dateFormat.parse(dateFormat.format(date)).getDate()) && !sessions.contains("session2")) {
                    if (db.insertContact("session2", date1, "0", "p",Double.toString(latitude),Double.toString(longitude)) >= 0) {
                        Toast.makeText(this, "Check-in successful.", Toast.LENGTH_LONG).show();
                    }
                }
                return;

            }

            d1 = sdf.parse("13:50");
            t1 = d1.getTime();
            d2 = sdf.parse("14:10");
            t2 = d2.getTime();
            if (t3 >= t1 && t3 <= t2) {

                if (!dates.contains(dateFormat.parse(dateFormat.format(date)).getDate())) {
                    if (db.insertContact("session3", date1, "0", "p",Double.toString(latitude),Double.toString(longitude)) >= 0) {
                        Toast.makeText(this, "Check-in successful.", Toast.LENGTH_LONG).show();
                    }
                }
                if (dates.contains(dateFormat.parse(dateFormat.format(date)).getDate()) && !sessions.contains("session3")) {
                    if (db.insertContact("session3", date1, "0", "p",Double.toString(latitude),Double.toString(longitude)) >= 0) {
                        Toast.makeText(this, "Check-in successful.", Toast.LENGTH_LONG).show();
                    }
                }
                return;

            }

        } catch (ParseException e) {
            e.printStackTrace();
        }


        db.close();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.profile, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.logout_menu) {

            Intent intent = new Intent(this, SecondActivity.class);
            this.startActivity(intent);
            return true;
        }
        if (id == R.id.viewprofile) {

            Intent intent = new Intent(this, viewprofile.class);
            this.startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {

                    Toast.makeText(getApplicationContext(),"denied", Toast.LENGTH_LONG).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request.
        }
    }
    private void requestPermissions() {
        // Permission has not been granted and must be requested.
        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed; request the permission
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        1);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }
    }
    class MylocListener implements LocationListener {


        public void onLocationChanged(Location loc) {
            // TODO Auto-generated method stub
            String text = " My location is  Latitude =" + loc.getLatitude() + " Longitude =" + loc.getLongitude();
            //Toast.makeText(getApplicationContext(),text,Toast.LENGTH_LONG).show();

//            Toast.makeText(home.this,text,Toast.LENGTH_LONG).show();
            latitude = loc.getLatitude() ;
            longitude = loc.getLongitude();

        }

        public void onProviderDisabled(String provider) {
            // TODO Auto-generated method stub
        }

        public void onProviderEnabled(String provider) {
            // TODO Auto-generated method stub
        }

        public void onStatusChanged(String provider, int status, Bundle extras) {
            // TODO Auto-generated method stub
        }
    }
}

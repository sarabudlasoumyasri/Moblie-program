package com.example.welcome.msit_attendance_track;

/**
 * Created by welcome on 4/14/2018.
 */


import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CustomListAdaptor1 extends ArrayAdapter {

    private final Activity act;
    private final String[]time1, penalty1,abpresent1,session1,latitude1,longitude1;

    public CustomListAdaptor1(Activity act, String[] session1,String[] time1, String[] penalty1,String[] abpresent1,String[] latitude1,String[] longitude1) {
        super(act, R.layout.viewattendlist, time1);

        this.act = act;
        this. time1 = time1;
        this.penalty1 = penalty1;
        this.abpresent1=abpresent1;
        this.session1=session1;
        this.latitude1=latitude1;
        this.longitude1=longitude1;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = act.getLayoutInflater();
        View row = layoutInflater.inflate(R.layout.viewattendlist, null, true);

        TextView timeTextField = (TextView)row.findViewById(R.id.name),
                penaltyTextField = (TextView)row.findViewById(R.id.grade),
                abpresentTextField = (TextView)row.findViewById(R.id.mentor),
                sessionTextField=(TextView)row.findViewById(R.id.textView7),
                latitudeTextField=(TextView)row.findViewById(R.id.textView5),
                logTextField=(TextView)row.findViewById(R.id.textView4);



        timeTextField.setText( time1[position]);
        penaltyTextField.setText(penalty1[position]);
        abpresentTextField.setText(abpresent1[position]);
        sessionTextField.setText(session1[position]);
        latitudeTextField.setText(latitude1[position]);
        logTextField.setText(longitude1[position]);

        return row;
    }
}


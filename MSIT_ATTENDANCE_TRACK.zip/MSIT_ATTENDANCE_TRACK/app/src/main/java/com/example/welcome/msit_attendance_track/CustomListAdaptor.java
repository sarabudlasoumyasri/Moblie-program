package com.example.welcome.msit_attendance_track;

/**
 * Created by welcome on 4/14/2018.
 */

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CustomListAdaptor extends ArrayAdapter {

    private final Activity act;
    private final String[] keys, values;

    public CustomListAdaptor(Activity act, String[] keys, String[] values) {
        super(act, R.layout.list, keys);

        this.act = act;
        this. keys = keys;
        this.values = values;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = act.getLayoutInflater();
        View row = layoutInflater.inflate(R.layout.list, null, true);

        TextView nameTextField = (TextView)row.findViewById(R.id.textView),
                detailsTextField = (TextView)row.findViewById(R.id.textView2);

        nameTextField.setText( keys[position]);
        detailsTextField.setText(values[position]);

        return row;
    }
}

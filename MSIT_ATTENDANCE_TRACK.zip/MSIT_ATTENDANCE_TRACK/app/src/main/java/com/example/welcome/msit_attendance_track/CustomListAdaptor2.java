package com.example.welcome.msit_attendance_track;

/**
 * Created by welcome on 4/14/2018.
 */

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class CustomListAdaptor2 extends ArrayAdapter {

    private final Activity act;
    private final String[]courseid,  coursename,grade,mentorname;

    public CustomListAdaptor2(Activity act, String[] courseid,String[] coursename, String[] grade,String[] mentorname) {
        super(act, R.layout.viewcourselist, courseid);

        this.act = act;
        this. courseid = courseid;
        this.coursename = coursename;
        this.grade=grade;
        this.mentorname=mentorname;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = act.getLayoutInflater();
        View row = layoutInflater.inflate(R.layout.viewcourselist, null, true);

        TextView nameTextField = (TextView)row.findViewById(R.id.name),
                gradeTextField = (TextView)row.findViewById(R.id.grade),
                mentorTextField = (TextView)row.findViewById(R.id.mentor),
                cidTextField=(TextView)row.findViewById(R.id.cid);

        cidTextField.setText( courseid[position]);
        nameTextField.setText(coursename[position]);
        gradeTextField.setText(grade[position]);
        mentorTextField.setText(mentorname[position]);

        return row;
    }
}

package com.example.welcome.msit_attendance_track;

/**
 * Created by welcome on 4/14/2018.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class viewprofile extends AppCompatActivity {
    String[] courseid = {}, coursename = {},grade={},mentorname={};
    List<String> courseid1 = new ArrayList<>(),coursename1 = new ArrayList<>(),grade1=new ArrayList<>(),mentorname1=new ArrayList<>();
    HashMap<String,Integer> coursecred=new HashMap<>();
    HashMap<String,Double> gradepoi=new HashMap<>();
    String Url = "http://msitis-iiith.appspot.com/api/course/ag5ifm1zaXRpcy1paWl0aHIUCxIHU3R1ZGVudBiAgICAq_OHCww";
    JsonObjectRequest jsonObjectRequest;

    ListView list;
    Activity act;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.coursesprofile);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        coursecred.put("Digital Literacy",1);coursecred.put("Computational Thinking",2);coursecred.put("CSPP-1",4);
        coursecred.put("CSPP-2",4);coursecred.put("ADS-1",4);coursecred.put("ADS-2",4);coursecred.put("DBMS",2);
        coursecred.put("Computer Networks",2);coursecred.put("Cyber Security",2);coursecred.put("Introduction to Computer Systems",4);
        coursecred.put("Software Engineering Foundations ",4);coursecred.put("Web Programming",3);
        gradepoi.put("Ex",10.0);gradepoi.put("A+",9.5);gradepoi.put("A",9.0);gradepoi.put("B+",8.5);gradepoi.put("B",8.0);gradepoi.put("C",7.0);
        act = this;

        RequestQueue queue = Volley.newRequestQueue(this);
        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, Url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray profile1 = response.getJSONArray("data");
                    for (int i = 0; i < profile1.length(); i++) {
                        JSONObject profile = profile1.getJSONObject(i);
                        if (profile.getString("course_id") != null && profile.getString("course_name") != null && profile.getString("grade") != null
                                && profile.getString("mentor_name") != null) {
                            courseid1.add(profile.getString("course_id"));
                            coursename1.add(profile.getString("course_name"));
                            grade1.add(profile.getString("grade"));
                            mentorname1.add(profile.getString("mentor_name"));
                        }
                        courseid = courseid1.toArray(courseid);
                        coursename = coursename1.toArray(coursename);
                        grade = grade1.toArray(grade);
                        mentorname = mentorname1.toArray(mentorname);
                        CustomListAdaptor2 adapter = new CustomListAdaptor2(act, courseid, coursename, grade, mentorname);
                        list = (ListView) findViewById(R.id.colist);
                        list.setAdapter(adapter);
                    }
                    double sum=0.0;
                    int totcred=0;
                    for(int i=0;i<coursename.length;i++)
                    {
                        if(!grade[i].equals("N/A"))
                        {
                            Log.d("apppppppppppp",coursename[i]);
                            sum=sum+(coursecred.get(coursename[i])*gradepoi.get(grade[i]));
                            totcred=totcred+coursecred.get(coursename[i]);
                        }
                    }
                    double avg=sum/totcred;
                    avg = Math.round(avg * 100D) / 100D;
                    TextView nameTextField = findViewById(R.id.textView8);
                    nameTextField.setText("CGPA: "+Double.toString(avg));

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        queue.add(jsonObjectRequest);
    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}